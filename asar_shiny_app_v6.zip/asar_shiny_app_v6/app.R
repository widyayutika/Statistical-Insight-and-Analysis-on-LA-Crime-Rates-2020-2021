
# Loading required libraries here
library(tibble)
library(randomForest)
library(ggplot2)
library(tmap)
library(plotly)
library(shiny)
library(DT)
library(dplyr)
library(shinydashboard)
library(data.table)
library(corrplot)
library(shinycssloaders)
library(shinydisconnect)
library(shinyscreenshot)
library(shinydashboardPlus)
library(shinyWidgets)

library(plyr)
library(RColorBrewer)
library(scales)
library(lubridate)
library(tidyverse)
library(ggbeeswarm)
library(leaflet)

library(BSDA)
library(PASWR)
library(Rmisc)
library(readr)


# @@@@@@@@@@@@@@@@@@@@@ START OF DATA PREPROCESSING CODE CHUNK @@@@@@@@@@@@@@@@@@@@@ 

data <- read_csv("crime_data_v1.csv")

# Keeping only 2020 and 2021 data
data <- filter(data, Year %in% c(2020, 2021))

#Victim Age grouping
age_group_label <-c("1-9","10-19","20-29","30-39","40-49","50-59","60-69","70-79",">=80")
age_group <- cut(data$Vict_Age, breaks=c(0,9,19,29,39,49,59,69,79,Inf), labels=c("1-9","10-19","20-29","30-39","40-49","50-59","60-69","70-79",">=80"))


#Adding new column Victim Age Group into the data
data$age_group <- age_group

uniqe_crm_code_category <- unique(data$Crm_Cd_Category)
unique_year <- unique(data$Year)
unique_month <- unique(data$Month)
unique_area_name <- unique(data$Area_Name)
unique_descent_desc <- unique(data$Vict_Descent_Description)
unique_gender <- unique(data$Vict_Sex)

# chisq_data %>% select(data.Crm_Cd_Category, data.Vict_Sex, data.Area_Name, data.Vict_Descent_Description, data.Month)

# @@@@@@@@@@@@@@@@@@@@@ END OF DATA PREPROCESSING CODE CHUNK @@@@@@@@@@@@@@@@@@@@@ 


# We set the global options here for shinycssloader, the spinner options.
# spinner.type Option 1 is like powerbi bar loading, option 6 is round comet like. Otherwise consider using gif.
# We can also change spinner color eg. spinner.color="#0dc5c1"
options(spinner.type = 6) 

sidebar <- dashboardSidebar(
    minified = TRUE, collapsed = FALSE, width = 265,
    
    sidebarMenu(
        # style = "position: fixed; overflow: visible;",
        menuItem("Getting Started", tabName = "tab0", icon = icon("info-circle")),
        # menuItem("Input Parameters", icon = icon("sliders"),
        #          selectInput(inputId = "Year",
        #                      label = "Year:",
        #                      choices = list(
        #                                     "2020" = 2020,
        #                                     "2021" = 2021),
        #                      selected = "2020"),
        #          textInput(
        #              inputId = "ticker1",
        #              label = "Input Stock Symbol 1 here:",
        #              value = "AAPL"
        #          )
        #          ),
        menuItem("Exploratory Analysis", tabName = "tab1", icon = icon("chart-line")),
        menuItem("Inferential Analysis", tabName = "tab2", icon = icon("pushed")),
        # menuItem("Forecasting Analysis", tabName = "tab3", icon = icon("bezier-curve")), # or use "balance-scale-left"
        # menuItem("Correlation/Clustering Analysis", tabName = "tab4", icon = icon("bezier-curve")),
        # menuItem("Forecasting Analysis", tabName = "tab5", icon = icon("battle-net")),
        screenshotButton()
    )
)


# body object defined here, will be fed into call to 'ui' object later below.
body <- dashboardBody(
    
    disconnectMessage(
        text = "Your session timed out, reload the application.",
        refresh = "Reload now",
        background = "#f89f43",
        colour = "white",
        overlayColour = "grey",
        overlayOpacity = 0.3,
        refreshColour = "brown"
    ),
    tabItems(
        tabItem(tabName = "tab0",
                fluidRow(
                    tabBox(width = 12,
                           tabPanel(title = "About this Shiny App",
                                    fluidRow(
                                        box(width = 4,
                                            uiOutput("active_side"),
                                            flipBox(
                                                id = "flipbox1", width = 12,
                                                front = div(class = "text-center",
                                                            h2("Click me"),
                                                            img(src = 'la_crime_hex_v1.png', height = "400px", width = "80%")
                                                ),
                                                back = div(
                                                    class = "text-center", height = "400px", width = "100%",
                                                    h2("Click to flip"),
                                                    p("Shiny Crime LA was built on R and deployed using shiny."),
                                                    br(),
                                                    p("Multiple R packages were used to build the final product. The key analysis packages used are: shiny, dplyr, lubridate, leaflet, etc."),
                                                    br(),
                                                    p("It is mainly put together based on the shinydashboardPlus package. Various other packages helped to add
                                                      towards improving the responsiveness, aesthetics, and general quality of life benefits to improve user experience.")
                                                )
                                            )),
                                        box(title = "Using this Shiny App", width = 8,
                                            div(
                                                class = "text-left",
                                                p("Navigate using tabs on the left sidebar to get started IMMEDIATELY."),
                                                br(),
                                                p("Alternatively, this page serves to provide a new user with some basic familiarity of Shiny Crime LA"),
                                                br(),
                                                p("Crime is one of the most concerning societal issues in every nation, generating substantial costs to society.
                                                  According to numerous prior studies, there are four fundamental costs caused by crimes such as victim costs, criminal justice system costs,
                                                  crime career costs, and intangible costs (i.e. psychological distress, fear, pain, and suffering). These intangible costs are equally concerning to society,
                                                  if not paid enough attention, may threaten the social and democracy stability of a country and cause a domino effect that increases the number and severity of crimes. "),
                                                br(),
                                                p("The objective of this Shiny App is to perform exploratory data analysis on crime that has occurred in LA over the past two years and subsequently provide insights
                                                  on the crime patterns and responses. The project will particularly look into the correlation between various demographic factors and types of crime as well as its frequency."),
                                                br(),
                                                p("The data set used is provided by the Los Angeles Police Department and extracted via the Los Angeles’ Open Data website.
                                                  The dataset reflects incidents of crime in Los Angeles, transcribed from original crime reports, from the period 2020-2021."),
                                                br(),
                                                p("To explore the data, please use the 'Exploratory Analysis' tab. It provides both a high level overview, and also the ability for you to deep-dive into the available crime data."),
                                                br(),
                                                p("The 'Inferential Analysis tab allows you to test various assumptions or ideas that you may have."),
                                                br(),
                                                p("Most of the visuals and underlying statistical tests are reactive in nature; i.e. they update in real time when relevant inputs are changed.")
                                                
                                                
                                            ))
                                    ))
                           # ,
                           # tabPanel(title = "Sub-Modules",
                           #          fluidRow(width = 6,
                           #                   box(title = "(A) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("Input Parameters allows users to key in and change various parameters to interaact with the app."),
                           #                           p("1) xxx")
                           #                       )),
                           #                   box(title = "(D) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("The Portfolio Analysis tab is split into 3 main logical segments:"),
                           #                           p("1) Top - xxx.")
                           #                       ))
                           #                   
                           #          ),
                           #          fluidRow(width = 6,
                           #                   box(title = "(B) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("The Technical Indicators tab is split into 2 main logical segments:"),
                           #                           p("1) Top - xxx")
                           #                       )),
                           #                   box(title = "(E) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("XXX")
                           #                       )
                           #                   )
                           #                   
                           #          ),
                           #          fluidRow(width = 6,
                           #                   box(title = "(C) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("The Correlation Analysis tab is split into 4 main logical segments:"),
                           #                           p("1) Top left - XXX.")
                           #                       )),
                           #                   box(title = "(F) XXX",
                           #                       div(
                           #                           class = "text-left",
                           #                           p("The Time Series XXX")
                           #                       )))
                           # )
                           )
                )
                
        ),
        tabItem(tabName = "tab1",
                # Button to simulate and test for disconnection, and disconnect message
                # actionButton("disconnect", "Disconnect the app"),
                
                fluidRow(
                    box(title = "Basic Exploratory Analysis Charts - all data", collapsible = TRUE, width = 12,
                        tabBox(width = 12,
                               tabPanel(title = "Age",
                                        withSpinner(plotlyOutput("Overall_Vict_Age")),
                                        withSpinner(plotlyOutput("Overall_Vict_Age_Boxplot"))
                               ),
                               tabPanel(title = "Gender",
                                        withSpinner(plotlyOutput("Overall_Vict_Gender"))
                               ),
                               tabPanel(title = "Descent/ Race",
                                        withSpinner(plotlyOutput("Overall_Vict_Descent"))
                               ),
                               tabPanel(title = "Map",
                                        withSpinner(leafletOutput("Overall_map", height = 750))
                               ),
                               tabPanel(title = "Others",
                                        withSpinner(plotlyOutput("overall_crime_cd_top10")),
                                        withSpinner(plotlyOutput("overall_area_name_top10"))
                               )
                        ) ) ) ,
                fluidRow(
                    box(title = "Reactive Inputs", collapsible = TRUE, width = 12,
                        pickerInput(inputId = "crm_cd_category_eda_1",
                                    label = "Crime Code Category",
                                    choices = uniqe_crm_code_category,
                                    # choices = c("Rape" = "Rape", "test1" = "test1"),
                                    selected = c("Simple Assault", "Rape", "Robbery"),
                                    options = list(`actions-box` = TRUE),
                                    multiple = TRUE),
                        pickerInput(inputId = "year_eda_1",
                                    label = "Year",
                                    choices = unique_year,
                                    selected = c("2020", "2021"),
                                    options = list(`actions-box` = TRUE),
                                    multiple = TRUE),
                        pickerInput(inputId = "month_eda_1",
                                    label = "Month",
                                    choices = unique_month,
                                    selected = c("January", "February", "March", "April", "May", "June",
                                                 "July", "August", "September", "October", "November", "December"),
                                    options = list(`actions-box` = TRUE),
                                    multiple = TRUE),
                        pickerInput(inputId = "area_name_eda_1",
                                    label = "Area Name",
                                    choices = unique_area_name,
                                    selected = c("Central", "West LA"),
                                    options = list(`actions-box` = TRUE),
                                    multiple = TRUE)
                        
                ),
                    box(title = "Deep Dive Exploratory Analysis Charts - selected categories", collapsible = TRUE, width = 12,
                        tabBox(width = 12,
                               tabPanel(title = "Age",
                                        withSpinner(plotlyOutput("Vict_Age_Group_Filter"))
                               ),
                               tabPanel(title = "Gender",
                                        withSpinner(plotlyOutput("Vict_Gender_Filter"))
                               ),
                               tabPanel(title = "Descent/ Race",
                                        withSpinner(plotlyOutput("Vict_Descent_Filter"))
                               ),
                               tabPanel(title = "Map",
                                        withSpinner(leafletOutput("deepdive_map", height = 750))
                               ),
                               tabPanel(title = "Time Heatmap",
                                        withSpinner(plotlyOutput("time_heatmap"))
                               ),
                               tabPanel(title = "Crime over Time",
                                        withSpinner(plotlyOutput("deepdive_crime_over_time"))
                               ),
                               tabPanel(title = "Top X",
                                        sliderInput(inputId = "top_x",
                                                    label = "Top X value",
                                                    min = 5,
                                                    max = 20,
                                                    value = c(10)),
                                        withSpinner(plotlyOutput("deepdive_crime_cd_topX")),
                                        withSpinner(plotlyOutput("deepdive_area_name_topX"))
                               )
                    ) ) )
                # ,
                # fluidRow(
                #     box(title = "Data Tables", collapsible = TRUE, width = 12,
                #         tabBox(width = 12)
                #     ) )
        ),
        
        tabItem(tabName = "tab2",
                fluidRow(
                    box(title = "Reactive Inputs - Main", collapsible = TRUE, width = 12,
                        pickerInput(inputId = "crm_cd_category_inf_1",
                                       label = "Crime Code Category",
                                       choices = uniqe_crm_code_category,
                                       # choices = c("Rape" = "Rape", "test1" = "test1"),
                                       selected = c("Simple Assault", "Rape", "Robbery"),
                                    options = list(`actions-box` = TRUE),
                                       multiple = TRUE),
                        pickerInput(inputId = "year_inf_1",
                                       label = "Year",
                                       choices = unique_year,
                                       selected = c("2020", "2021"),
                                    options = list(`actions-box` = TRUE),
                                       multiple = TRUE),
                        pickerInput(inputId = "month_inf_1",
                                       label = "Month",
                                       choices = unique_month,
                                       selected = c("January", "February", "March", "April", "May", "June",
                                                    "July", "August", "September", "October", "November", "December"),
                                    options = list(`actions-box` = TRUE),
                                       multiple = TRUE),
                        pickerInput(inputId = "area_name_inf_1",
                                       label = "Area Name",
                                       choices = unique_area_name,
                                       selected = c("Central", "West LA"),
                                    options = list(`actions-box` = TRUE),
                                       multiple = TRUE),
                        pickerInput(inputId = "descent_inf_1",
                                       label = "Race/ Descent",
                                       choices = unique_descent_desc,
                                       selected = c("Hispanic/Latin/Mexican", "Chinese"),
                                    options = list(`actions-box` = TRUE),
                                       multiple = TRUE),
                        pickerInput(inputId = "gender_inf_1",
                                    label = "Gender",
                                    choices = unique_gender,
                                    selected = c("M", "F"),
                                    options = list(`actions-box` = TRUE),
                                    multiple = TRUE)
                    )),
                fluidRow(
                    box(title = "Confidence Intervals", collapsible = TRUE, width = 12, collapsed = TRUE,
                        splitLayout(
                        numericInput(inputId = "conf_level_CI",
                                    label = "Confidence Level",
                                    min = 0.75,
                                    max = 1.00,
                                    value = c(0.95)),
                        numericInput(inputId = "sample_size_CI",
                                     label = "Sample Size",
                                     min = 30,
                                     max = 99999,
                                     value = c(30))
                        ),
                        div(
                            class = "text-left",
                            br(),
                            textOutput("inf_CI_results"),
                            br()
                        )
                    ) ),
                
                fluidRow(
                    box(title = "Hypothesis Testing", collapsible = TRUE, width = 12, collapsed = TRUE,
                        
                        tabBox(width = 12,
                               tabPanel(title = "Group 2 Reactive Inputs",
                                        pickerInput(inputId = "crm_cd_category_inf_2",
                                                    label = "Crime Code Category",
                                                    choices = uniqe_crm_code_category,
                                                    # choices = c("Rape" = "Rape", "test1" = "test1"),
                                                    selected = c("Simple Assault", "Rape", "Robbery"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        pickerInput(inputId = "year_inf_2",
                                                    label = "Year",
                                                    choices = unique_year,
                                                    selected = c("2020", "2021"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        pickerInput(inputId = "month_inf_2",
                                                    label = "Month",
                                                    choices = unique_month,
                                                    selected = c("January", "February", "March", "April", "May", "June",
                                                                 "July", "August", "September", "October", "November", "December"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        pickerInput(inputId = "area_name_inf_2",
                                                    label = "Area Name",
                                                    choices = unique_area_name,
                                                    selected = c("Central", "West LA"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        pickerInput(inputId = "descent_inf_2",
                                                    label = "Race/ Descent",
                                                    choices = unique_descent_desc,
                                                    selected = c("Hispanic/Latin/Mexican", "Chinese"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        pickerInput(inputId = "gender_inf_2",
                                                    label = "Gender",
                                                    choices = unique_gender,
                                                    selected = c("M", "F"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE)
                               ),
                               tabPanel(title = "Test Specific Parameters & Results",
                                        splitLayout(
                                            numericInput(inputId = "conf_level_HT",
                                                         label = "Confidence Level",
                                                         min = 0.75,
                                                         max = 1.00,
                                                         value = c(0.95)),
                                            numericInput(inputId = "sample_size_HT",
                                                         label = "Sample Size",
                                                         min = 30,
                                                         max = 99999,
                                                         value = c(30)),
                                            pickerInput(inputId = "comparison_alternative_ht",
                                                        label = "Comparison Direction",
                                                        choices = list("Less" = "less", "Greater" = "greater", "Two.sided" = "two.sided"),
                                                        selected = "less",
                                                        options = list(`actions-box` = TRUE),
                                                        width = 'fit',
                                                        multiple = FALSE)
                                        ),
                                        div(
                                            class = "text-left",
                                            br(),
                                            textOutput("inf_HT_results"),
                                            br()
                                        ))
                               )
                        
                        
                    ) ),
                fluidRow(
                    box(title = "ANOVA", collapsible = TRUE, width = 12, collapsed = TRUE,
                        splitLayout(
                            numericInput(inputId = "sample_size_ANOV",
                                         label = "Sample Size",
                                         min = 6,
                                         max = 12,
                                         value = c(10))
                        ),
                        tabBox(width = 12,
                               tabPanel(title = "Gender",
                                    withSpinner(DTOutput('inf_anova_table_gender', height = '400') )
                                    ),
                               tabPanel(title = "Crime Code",
                                        pickerInput(inputId = "crm_cd_category_inf_ANOV",
                                                    label = "Crime Code Category",
                                                    choices = uniqe_crm_code_category,
                                                    # choices = c("Rape" = "Rape", "test1" = "test1"),
                                                    selected = c("Simple Assault", "Rape", "Robbery"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        withSpinner(DTOutput('inf_anova_table_crime_code', height = '400') )
                               ),
                               tabPanel(title = "Race",
                                        pickerInput(inputId = "descent_inf_ANOV",
                                                    label = "Race/ Descent",
                                                    choices = unique_descent_desc,
                                                    selected = c("Hispanic/Latin/Mexican", "Chinese", "Vietnamese"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        withSpinner(DTOutput('inf_anova_table_race', height = '400') )
                               ),
                               tabPanel(title = "Area Name",
                                        pickerInput(inputId = "area_name_inf_ANOV",
                                                    label = "Area Name",
                                                    choices = unique_area_name,
                                                    selected = c("Central", "West LA", "N Hollywood", "Pacific"),
                                                    options = list(`actions-box` = TRUE),
                                                    multiple = TRUE),
                                        withSpinner(DTOutput('inf_anova_table_area_name', height = '400') )
                               )
                        
                        
                        )
                    ) ),
                fluidRow(
                    box(title = "Chi-Squared Test of Association", collapsible = TRUE, width = 12, collapsed = TRUE,
                        # varSelectInput(inputId = "chisq_var1",
                        #                label = "Select Var 1",
                        #                data = data,
                        #                selected = "Crm_Cd_Category",
                        #                multiple = FALSE),
                        # varSelectInput(inputId = "chisq_var2",
                        #                label = "Select Var 2",
                        #                data = data,
                        #                selected = "Vict_Descent_Description",
                        #                multiple = FALSE),
                        
                        # Do at least 2 tabs, 1 more tab for Crm_Cd_Category vs Area_name!
                        tabBox(width = 12,
                               tabPanel(title = "Crime Code Category and Race",
                        div(
                            class = "text-left",
                            br(),
                            textOutput("inf_chisq_results_1"),
                            br()
                        ),
                        
                        withSpinner(tableOutput('inf_chisq_table_1') )
                        # tabBox(width = 12)
                        ),
                        tabPanel(title = "Crime Code Category and Area Name",
                                 div(
                                     class = "text-left",
                                     br(),
                                     textOutput("inf_chisq_results_2"),
                                     br()
                                 ),
                                 
                                 withSpinner(tableOutput('inf_chisq_table_2') )
                                 # tabBox(width = 12)
                        ),
                        tabPanel(title = "Crime Code Category and Gender",
                                 div(
                                     class = "text-left",
                                     br(),
                                     textOutput("inf_chisq_results_3"),
                                     br()
                                 ),
                                 
                                 withSpinner(tableOutput('inf_chisq_table_3') )
                                 # tabBox(width = 12)
                        )
                        )
                        
                    ) )
                
        )
    )
)


# UI Object
ui <- dashboardPage(
    md = TRUE,
    skin = "green-light",
    options = list(sidebarExpandOnHover = TRUE),
    dashboardHeader(title = tagList(
        span(class = "logo-lg", "Shiny Crime LA", width = 265),
        img(src = 'la_crime_hex_v1.png', width = 30, height = 30) # align = "center", noWS = NULL
    ) ),
    sidebar,
    body,
    controlbar = dashboardControlbar(collapsed = TRUE, skinSelector()),
    footer = dashboardFooter(left = "Made with R Shiny", right = "Singapore, 2022"),
    title = "Skin Selector")


# Server Object
server <- function(input, output, session){
    
    # Having a test button to disconnect the app
    observeEvent(input$disconnect, {
        session$close()
    })
    
    
    output$active_side <- renderUI({
        side <- if (input$flipbox1) "front" else "back"
        dashboardBadge(side, color = "blue")
    })

# Put all the code logic over here!

    # @@@@@@@@@@@@@@@@@@@@@ START OF EXPLORATORY ANALYSIS CODE CHUNK @@@@@@@@@@@@@@@@@@@@@ 
# This portion for BASIC EDA!
    output$Overall_Vict_Age <- renderPlotly({
        Overall_Vict_Age<-data %>%
            filter(age_group!="NA")%>%
            group_by(age_group)%>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>% 
            ggplot(aes(x=age_group, y=counts, fill=percentage)) +                  
            geom_bar(stat="identity")+
            xlab("Age Group") +
            ylab("Total occurences") +
            labs(title = 'Victim Age Group Overall Distribution')
        ggplotly(Overall_Vict_Age)
    
    })
    
    output$Overall_Vict_Age_Boxplot <- renderPlotly({
        Overall_Vict_Age_Boxplot <- ggplot(data=data,
                                           aes(x=" ",y=Vict_Age)) +
            geom_boxplot() +
            ylab("Victim Age") +
            stat_summary(geom = "point",
                         fun = "mean",
                         colour = "green",
                         size = 2)
        ggplotly(Overall_Vict_Age_Boxplot)
        
    })
    
    output$Overall_Vict_Gender <- renderPlotly({
        Overall_Vict_Gender<-data %>%
            group_by(Vict_Sex) %>%
            filter(Vict_Sex!="NA" & Vict_Sex!="H")%>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>% 
            ggplot(aes(x=Vict_Sex, y=counts, fill=percentage)) +                   
            geom_bar(stat="identity")+
            xlab("Victim Gender") +
            ylab("Total occurences") +
            labs(title = 'Victim Gender Overall Distribution')
        ggplotly(Overall_Vict_Gender)
        
    })
    
    output$Overall_Vict_Descent <- renderPlotly({
        Overall_Vict_Descent<-data %>%
            group_by(Vict_Descent_Description) %>%                                                               
            filter(Vict_Descent_Description!='NA') %>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>% 
            ggplot(aes(x=Vict_Descent_Description, y=counts, fill=percentage)) +                                                  
            geom_bar(stat="identity")+
            xlab("Victim Descent") +
            ylab("Total occurences") +
            labs(title = 'Total occurences by Victim Descent')+
            theme(axis.text.x = element_text(angle = 90))
        ggplotly(Overall_Vict_Descent)
        
    })
    
    output$Overall_map <- renderLeaflet({
        df<-data%>%
            filter(Lat!=0)
            # filter(Crm_Cd_Category=="Rape") %>%
            # filter(Area_Name=="Central")
        df$popup<-paste("<b>Report Number #: </b>", df$Dr_No, "<br>", "<b>Category: </b>", df$Crm_Cd_Category,
                        "<br>", "<b>Description: </b>", str_to_sentence(df$Crm_Cd_Desc, locale = "en"),
                        "<br>", "<b>Day of week: </b>", df$Day,
                        "<br>", "<b>Date: </b>", df$Date_Occ,
                        "<br>", "<b>Time: </b>", df$Time,
                        "<br>", "<b>Police Station Area Name: </b>", df$Area_Name,
                        "<br>", "<b>Longitude: </b>", df$Lon,
                        "<br>", "<b>Latitude: </b>", df$Lat)
        # library(leaflet)
        leaflet(df, width = "100%") %>% addTiles() %>%
            addTiles(group = "OSM (default)") %>%
            addProviderTiles(provider = "Esri.WorldImagery",group = "World Imagery") %>%
            addMarkers(lng = ~Lon, lat = ~Lat, popup = df$popup, clusterOptions = markerClusterOptions()) %>%
            addLayersControl(
                baseGroups = c("OSM (default)", "World Imagery"),
                options = layersControlOptions(collapsed = FALSE)
            )
        
    })
    
    # withSpinner(plotlyOutput("overall_crime_cd_top10")),
    # withSpinner(plotlyOutput("overall_area_name_top10"))
    
    output$overall_crime_cd_top10 <- renderPlotly({
        Top10Crime<- data %>%
            # filter(Year==2020)%>%
            group_by(Crm_Cd_Category) %>%                                             
            dplyr::summarize(counts = n()) %>%
            arrange(-counts) %>%                                                      
            slice(1:10)%>%
            ggplot(aes(x=reorder(Crm_Cd_Category,-counts), y=counts, fill=counts)) +                                
            geom_bar(stat="identity")+
            xlab("Crime Code Category") +
            ylab("Total occurences") +
            labs(title = 'Top 10 Crimes')
        ggplotly(Top10Crime)
        
    })
    output$overall_area_name_top10 <- renderPlotly({
        Top5Area_name<- data %>%
            # filter(Year==2020)%>%
            group_by(Area_Name) %>%                                             
            dplyr::summarize(counts = n()) %>%
            arrange(-counts) %>%                                                      
            slice(1:10)%>%
            ggplot(aes(x=reorder(Area_Name,-counts), y=counts, fill=counts)) +                                
            geom_bar(stat="identity")+
            xlab("Crime Code Category") +
            ylab("Total occurences") +
            labs(title = 'Top 10 Areas')
        ggplotly(Top5Area_name)
        
    })
    
    
# THIS PORTION FOR DEEP DIVE EDA!
    output$Vict_Age_Group_Filter <- renderPlotly({
        Vict_Age_Group_Filter<-data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)%>%
            group_by(age_group)%>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>%
            ggplot(aes(x=age_group, y=counts, fill=percentage)) +               
            geom_bar(stat="identity")+
            xlab("Age Group") +
            ylab("Total occurences") +
            labs(title = 'Total occurences of Crime based on Reactive Inputs')
        ggplotly(Vict_Age_Group_Filter)
        
    })
    
    output$Vict_Gender_Filter <- renderPlotly({
        Vict_Gender_Filter<-data %>%
            filter(Vict_Sex!="NA")%>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)%>%
            group_by(Vict_Sex)%>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>%
            ggplot(aes(x=Vict_Sex, y=counts, fill=percentage)) +                  
            geom_bar(stat="identity")+
            xlab("Victim Gender") +
            ylab("Total occurences") +
            labs(title = 'Total occurences of Crime based on Reactive Inputs')
        ggplotly(Vict_Gender_Filter)
        
    })
    
    output$Vict_Descent_Filter <- renderPlotly({
        Vict_Descent_Filter<-data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)%>%
            group_by(Vict_Descent_Description)%>%
            dplyr::summarize(counts = n()) %>%
            mutate(percentage = round(counts/sum(counts),2)) %>%
            ggplot(aes(x=Vict_Descent_Description, y=counts, fill=percentage)) +                  # plot 
            geom_bar(stat="identity")+
            xlab("Victim Descent") +
            ylab("Total occurences") +
            labs(title = 'Total occurences of Crime based on Reactive Inputs')
        ggplotly(Vict_Descent_Filter)
        
    })
    
    output$time_heatmap <- renderPlotly({
        df_time <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)%>%
            transform(Hour=as.numeric(Hour)) %>%
            group_by(Day,Hour, .groups="keep") %>%
            dplyr::summarize(count = n())
        df_time
        dow_format <- c("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
        hour_format <- c("12 AM","1 AM","2 AM","3 AM","4 AM","5 AM","6 AM","7 AM","8 AM","9 AM","10 AM","11 AM","12 PM","1 PM","2 PM","3 PM","4 PM","5 PM","6 PM","7 PM","8 PM","9 PM","10 PM","11 PM")
        df_time$Day <- factor(df_time$Day, level = rev(dow_format))
        df_time$Hour <- factor(df_time$Hour, level = 0:23, label = hour_format)
        
        heatmap <- ggplot(df_time, aes(x = Hour, y = Day, fill = count)) +
            geom_tile() +
            theme(axis.text.x = element_text(angle = 90, vjust = 0.6), legend.title = element_blank(), legend.position="top", legend.key.width=unit(2, "cm"), legend.key.height=unit(0.25, "cm"), panel.spacing = element_blank()) +
            labs(x = "Hour Of Occurences (Local Time)", y = "Day of Week of Occurences", title = "Number of Report in LA by Time of Occurences, based on Reactive Inputs") +
            scale_fill_gradient(low = "white", high = "#27AE60", labels = comma)
        ggplotly(heatmap)
        
    })
    
    output$deepdive_map <- renderLeaflet({
        df<-data%>%
            filter(Lat!=0)%>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)
        df$popup<-paste("<b>Report Number #: </b>", df$Dr_No, "<br>", "<b>Category: </b>", df$Crm_Cd_Category,
                        "<br>", "<b>Description: </b>", str_to_sentence(df$Crm_Cd_Desc, locale = "en"),
                        "<br>", "<b>Day of week: </b>", df$Day,
                        "<br>", "<b>Date: </b>", df$Date_Occ,
                        "<br>", "<b>Time: </b>", df$Time,
                        "<br>", "<b>Police Station Area Name: </b>", df$Area_Name,
                        "<br>", "<b>Longitude: </b>", df$Lon,
                        "<br>", "<b>Latitude: </b>", df$Lat)
        # library(leaflet)
        leaflet(df, width = "100%") %>% addTiles() %>%
            addTiles(group = "OSM (default)") %>%
            addProviderTiles(provider = "Esri.WorldImagery",group = "World Imagery") %>%
            addMarkers(lng = ~Lon, lat = ~Lat, popup = df$popup, clusterOptions = markerClusterOptions()) %>%
            addLayersControl(
                baseGroups = c("OSM (default)", "World Imagery"),
                options = layersControlOptions(collapsed = FALSE)
            )
        
    })
    
    output$deepdive_crime_over_time <- renderPlotly({
        crimetype <- data %>% 
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1)
        crime_daily <- crimetype %>%
            mutate(Date = as.Date(Date_Occ, "%d/%m/%Y")) %>%
            group_by(Date) %>%
            dplyr::summarize(counts = n()) %>%
            arrange(Date)
        crime_daily
        plot <- ggplot(crime_daily, aes(x = Date, y = counts)) +
            geom_line(color = "#4287f5", size = 0.1) +
            geom_smooth(color = "#cc2b73") +
            scale_x_date(breaks = date_breaks("1 year"), labels = date_format("%Y")) +
            labs(x = "Date of Crime", y = "Number of Crimes", title = "Daily Crimes in LA City, based on reactive inputs")
        ggplotly(plot)
        
    })
    
    output$deepdive_crime_cd_topX <- renderPlotly({
        TopXCrime<- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1) %>%
            # filter(Year==2020)%>%
            group_by(Crm_Cd_Category) %>%                                             
            dplyr::summarize(counts = n()) %>%
            arrange(-counts) %>%                                                      
            slice(1:input$top_x)%>%
            ggplot(aes(x=reorder(Crm_Cd_Category,-counts), y=counts, fill=counts)) +                                
            geom_bar(stat="identity")+
            xlab("Crime Code Category") +
            ylab("Total occurences") +
            labs(title = 'Top X Crimes')
        ggplotly(TopXCrime)
        
    })
    output$deepdive_area_name_topX <- renderPlotly({
        TopXArea_name<- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_eda_1)%>%
            filter(Year %in% input$year_eda_1)%>%
            filter(Month %in% input$month_eda_1)%>%
            filter(Area_Name %in% input$area_name_eda_1) %>%
            # filter(Year==2020)%>%
            group_by(Area_Name) %>%                                             
            dplyr::summarize(counts = n()) %>%
            arrange(-counts) %>%                                                      
            slice(1:input$top_x)%>%
            ggplot(aes(x=reorder(Area_Name,-counts), y=counts, fill=counts)) +                                
            geom_bar(stat="identity")+
            xlab("Area Names") +
            ylab("Total occurences") +
            labs(title = 'Top X Areas')
        ggplotly(TopXArea_name)
        
    })
    
    
    # THIS PORTION FOR INFERENTIAL ANALYSIS!
    
    output$inf_CI_results <- renderText({ 
        crime_2020 <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        sum_groupby_2020 <- data.frame(table(crime_2020$Date_Occ))
        colnames(sum_groupby_2020) <- c('Date','Frequency')
        mean_2020 <- mean(sum_groupby_2020$Frequency)
        sd_2020 <- sd(sum_groupby_2020$Frequency)
        
        sample_2020 <- sample_n(sum_groupby_2020, input$sample_size_CI)
        
        CI <- CI(sample_2020$Frequency, ci = input$conf_level_CI)
        
        paste("Based on the selected inputs, the Confidence Interval for the Daily crime rate ranges from a Lower Bound of ", round(CI[3],2),
              " to a Upper Bound of ", round(CI[1],2), ", with a mean of ", round(CI[2],2), "." )
    })
    
    output$inf_HT_results <- renderText({ 
        crime_2020_s <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
            # filter(Year == 2020,
            #        Vict_Sex == 'F',
            #        Vict_Descent == 'C')
        
        sum_groupby_2020_s <- data.frame(table(crime_2020_s$Date_Occ))
        colnames(sum_groupby_2020_s) <- c('Date','Frequency')
        mean_2020_s <- mean(sum_groupby_2020_s$Frequency)
        sd_2020_s <- sd(sum_groupby_2020_s$Frequency)
        
        crime_2021_s <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_2)%>%
            filter(Year %in% input$year_inf_2)%>%
            filter(Month %in% input$month_inf_2)%>%
            filter(Area_Name %in% input$area_name_inf_2) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_2) %>%
            filter(Vict_Sex %in% input$gender_inf_2)
            # filter(Year == 2021,
            #        Vict_Sex == 'F',
            #        Vict_Descent == 'C')
        
        sum_groupby_2021_s <- data.frame(table(crime_2021_s$Date_Occ))
        colnames(sum_groupby_2021_s) <- c('Date','Frequency')
        mean_2021_s <- mean(sum_groupby_2021_s$Frequency)
        sd_2021_s <- sd(sum_groupby_2021_s$Frequency)
        
        sample_2020_s <- sample_n(sum_groupby_2020_s, input$sample_size_HT)
        sample_2021_s <- sample_n(sum_groupby_2021_s, input$sample_size_HT)
        # z.test(sample_2020_s$Frequency, sample_2021_s$Frequency, alternative ="less",
        #        sigma.x = sd_2020_s, sigma.y = sd_2021_s, conf.level = 0.95)
        ztest_results <- z.test(sample_2020_s$Frequency, sample_2021_s$Frequency, alternative = input$comparison_alternative_ht,
               sigma.x = sd_2020_s, sigma.y = sd_2021_s, conf.level = input$conf_level_HT)

        # paste("The Z-test results are: ", ztest_results)
        # paste("z1: ", ztest_results[1], "z2: ", ztest_results[2], "z3: ", ztest_results[3],
        #       "z4: ", ztest_results[4], "z5: ", ztest_results[5], "z6: ", ztest_results[6], "z7: ", ztest_results[7])
        
        if (input$comparison_alternative_ht == "less") {
            # less
            if (ztest_results[2] < (1-input$conf_level_HT) ) {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is greater or equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is LESS than Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and conclude that the Sample Mean for Group 1 is lesser than the Sample Mean for Group 2.")
            } else {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is greater or equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is LESS than Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO NOT have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and are UNABLE to conclude that the Sample Mean for Group 1 is lesser than the Sample Mean for Group 2.")
            }
        } else if (input$comparison_alternative_ht == "greater") {
            if (ztest_results[2] < (1-input$conf_level_HT) ) {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is lesser or equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is GREATER than Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and conclude that the Sample Mean for Group 1 is GREATER than the Sample Mean for Group 2.")
            } else {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is lesser or equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is GREATER than Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO NOT have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and are UNABLE to conclude that the Sample Mean for Group 1 is greater than the Sample Mean for Group 2.")
            }
        } else {
            if (ztest_results[2] < (1-input$conf_level_HT) ) {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is NOT EQUAL to Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and conclude that the Sample Mean for Group 1 is NOT EQUAL to the Sample Mean for Group 2.")
            } else {
                paste("A 2 sample z-test has been performed. H0: Sample Mean for Group 1 is equal to Sample Mean for Group 2.
              H1: Sample Mean for Group 1 is NOT EQUAL to Sample Mean for Group 2.",
                      "The P-value from the test is: ", ztest_results[2], ", and so we DO NOT have sufficient evidence at the Alpha = ", (1-input$conf_level_HT),
                      " to reject H0, and are UNABLE to conclude that the Sample Mean for Group 1 is not equal to the Sample Mean for Group 2.")
            }
        }

        
    })

    
    output$inf_anova_table_gender <- renderDT({
    
        crime <- data.frame(data$Vict_Sex,data$Month) #Filter sex and month column
        crime_s <- data.frame(table(crime)) #Sum and group by
        colnames(crime_s) <- c('Gender','Month','Frequency')
        
        crime_filtered <- crime_s %>%
            filter(Gender != '',
                   Gender != 'H') 
        sample <- sample_n(crime_filtered, input$sample_size_ANOV)
        
        res.aov <- aov(sample$Frequency ~ sample$Gender, 
                       data = sample)
        
        tukey_t1 <- TukeyHSD(res.aov)
        tukey_df <- datatable(as.data.frame(tukey_t1[1]),
                              filter = 'top', caption = paste0("Data"), extensions = c("Buttons"),
                              options = list(scrollX = TRUE, scrollY = "200px",
                                             dom = 'Bfrtip',
                                             buttons = list(
                                                 list(extend = "csv", text = "Download Current Page", filename = "page",
                                                      exportOptions = list(
                                                          modifier = list(page = "current")
                                                      )
                                                 ),
                                                 list(extend = "csv", text = "Download Full Results", filename = "data",
                                                      exportOptions = list(
                                                          modifier = list(page = "all")
                                                      )
                                                 )
                                                 
                                                 
                                             )
                                             
                              )
                              )
        # tukey_df
        
    })
    
    output$inf_anova_table_crime_cd <- renderDT({
        
        crime <- data.frame(data$Crm_Cd_Category,data$Month) #Filter crm cd and month column
        crime_s <- data.frame(table(crime)) #Sum and group by
        colnames(crime_s) <- c('Crime_code','Month','Frequency')
        
        crime_filtered <- crime_s %>%
            filter(Crime_code != '',
                   Crime_code != 'xxx')  %>%
            filter(Crime_code %in% input$crm_cd_category_inf_ANOV)
        
        sample <- sample_n(crime_filtered, input$sample_size_ANOV)
        
        res.aov <- aov(sample$Frequency ~ sample$Crime_code, 
                       data = sample)
        
        tukey_t1 <- TukeyHSD(res.aov)
        tukey_df <- datatable(as.data.frame(tukey_t1[1]),
                              filter = 'top', caption = paste0("Data"), extensions = c("Buttons"),
                              options = list(scrollX = TRUE, scrollY = "200px",
                                             dom = 'Bfrtip',
                                             buttons = list(
                                                 list(extend = "csv", text = "Download Current Page", filename = "page",
                                                      exportOptions = list(
                                                          modifier = list(page = "current")
                                                      )
                                                 ),
                                                 list(extend = "csv", text = "Download Full Results", filename = "data",
                                                      exportOptions = list(
                                                          modifier = list(page = "all")
                                                      )
                                                 )
                                                 
                                                 
                                             )
                                             
                              )
        )
        # tukey_df
        
    })
    
    output$inf_anova_table_race <- renderDT({
        
        crime <- data.frame(data$Vict_Descent_Description,data$Month) #Filter race and month column
        crime_s <- data.frame(table(crime)) #Sum and group by
        colnames(crime_s) <- c('Race','Month','Frequency')
        
        crime_filtered <- crime_s %>%
            filter(Race != '',
                   Race != 'xxx')  %>%
            filter(Race %in% input$descent_inf_ANOV)
        
        sample <- sample_n(crime_filtered, input$sample_size_ANOV)
        
        res.aov <- aov(sample$Frequency ~ sample$Race, 
                       data = sample)
        
        tukey_t1 <- TukeyHSD(res.aov)
        tukey_df <- datatable(as.data.frame(tukey_t1[1]),
                              filter = 'top', caption = paste0("Data"), extensions = c("Buttons"),
                              options = list(scrollX = TRUE, scrollY = "200px",
                                             dom = 'Bfrtip',
                                             buttons = list(
                                                 list(extend = "csv", text = "Download Current Page", filename = "page",
                                                      exportOptions = list(
                                                          modifier = list(page = "current")
                                                      )
                                                 ),
                                                 list(extend = "csv", text = "Download Full Results", filename = "data",
                                                      exportOptions = list(
                                                          modifier = list(page = "all")
                                                      )
                                                 )
                                                 
                                                 
                                             )
                                             
                              )
        )
        # tukey_df
        
    })
    
    output$inf_anova_table_area_name <- renderDT({
        
        crime <- data.frame(data$Area_Name,data$Month) #Filter area name and month column
        crime_s <- data.frame(table(crime)) #Sum and group by
        colnames(crime_s) <- c('Area_Name','Month','Frequency')
        
        crime_filtered <- crime_s %>%
            filter(Area_Name != '',
                   Area_Name != 'xxx')  %>%
            filter(Area_Name %in% input$area_name_inf_ANOV)
        
        sample <- sample_n(crime_filtered, input$sample_size_ANOV)
        
        res.aov <- aov(sample$Frequency ~ sample$Area_Name, 
                       data = sample)
        
        tukey_t1 <- TukeyHSD(res.aov)
        tukey_df <- datatable(as.data.frame(tukey_t1[1]),
                              filter = 'top', caption = paste0("Data"), extensions = c("Buttons"),
                              options = list(scrollX = TRUE, scrollY = "200px",
                                             dom = 'Bfrtip',
                                             buttons = list(
                                                 list(extend = "csv", text = "Download Current Page", filename = "page",
                                                      exportOptions = list(
                                                          modifier = list(page = "current")
                                                      )
                                                 ),
                                                 list(extend = "csv", text = "Download Full Results", filename = "data",
                                                      exportOptions = list(
                                                          modifier = list(page = "all")
                                                      )
                                                 )
                                                 
                                                 
                                             )
                                             
                              )
        )
        # tukey_df
        
    })
    
    output$inf_chisq_results_1 <- renderText({ 
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        var1 <- paste0("data_chisq$",input$chisq_var1)
        var2 <- paste0("data_chisq$",input$chisq_var2)
        
        # combined <- paste(var1, ",", var2)
        
        # Result <- chisq.test(eval(as.name(var1)), eval(as.name(var2)),correct=FALSE)
        Result <- chisq.test(data_chisq$Crm_Cd_Category,data_chisq$Vict_Descent,correct=FALSE)

        if (Result[3] < 0.05) {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is significant, we can continue on to analyse the cross tab/ matrix of these 2 variables to further derive insights." )
        } else {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is NOT significant, the cross tab/ matrix of these 2 variables may not yield insights that are statistically significant." )
        }
        
    })
    
    output$inf_chisq_table_1 <- renderTable({
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        tbl <- table(data_chisq$Crm_Cd_Category,data_chisq$Vict_Descent_Description)
        as.data.frame.matrix(tbl, striped=TRUE, bordered = TRUE
                             # rownames = T,
                             # colnames = T
                             )
        
    }, rownames = TRUE
    )
    
    output$inf_chisq_results_2 <- renderText({ 
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        var1 <- paste0("data_chisq$",input$chisq_var1)
        var2 <- paste0("data_chisq$",input$chisq_var2)
        
        # combined <- paste(var1, ",", var2)
        
        # Result <- chisq.test(eval(as.name(var1)), eval(as.name(var2)),correct=FALSE)
        Result <- chisq.test(data_chisq$Crm_Cd_Category,data_chisq$Area_Name,correct=FALSE)
        
        if (Result[3] < 0.05) {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is significant, we can continue on to analyse the cross tab/ matrix of these 2 variables to further derive insights." )
        } else {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is NOT significant, the cross tab/ matrix of these 2 variables may not yield insights that are statistically significant." )
        }
        
    })
    
    output$inf_chisq_table_2 <- renderTable({
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        tbl <- table(data_chisq$Crm_Cd_Category,data_chisq$Area_Name)
        as.data.frame.matrix(tbl, striped=TRUE, bordered = TRUE
                             # rownames = T,
                             # colnames = T
        )
        
    }, rownames = TRUE
    )
    
    output$inf_chisq_results_3 <- renderText({ 
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        var1 <- paste0("data_chisq$",input$chisq_var1)
        var2 <- paste0("data_chisq$",input$chisq_var2)
        
        # combined <- paste(var1, ",", var2)
        
        # Result <- chisq.test(eval(as.name(var1)), eval(as.name(var2)),correct=FALSE)
        Result <- chisq.test(data_chisq$Crm_Cd_Category,data_chisq$Vict_Sex,correct=FALSE)
        
        if (Result[3] < 0.05) {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is significant, we can continue on to analyse the cross tab/ matrix of these 2 variables to further derive insights." )
        } else {
            paste("Based on the selected inputs running through a Chi-Squared Test, the p-value is: ", Result[3],
                  ". As the result is NOT significant, the cross tab/ matrix of these 2 variables may not yield insights that are statistically significant." )
        }
        
    })
    
    output$inf_chisq_table_3 <- renderTable({
        
        data_chisq <- data %>%
            filter(Crm_Cd_Category %in% input$crm_cd_category_inf_1)%>%
            filter(Year %in% input$year_inf_1)%>%
            filter(Month %in% input$month_inf_1)%>%
            filter(Area_Name %in% input$area_name_inf_1) %>%
            filter(Vict_Descent_Description %in% input$descent_inf_1) %>%
            filter(Vict_Sex %in% input$gender_inf_1)
        
        tbl <- table(data_chisq$Crm_Cd_Category,data_chisq$Vict_Sex)
        as.data.frame.matrix(tbl, striped=TRUE, bordered = TRUE
                             # rownames = T,
                             # colnames = T
        )
        
    }, rownames = TRUE
    )
    
    
}


# Run the application 
shinyApp(ui = ui, server = server)


# List of open source resources used for convenient reference:
# https://gist.github.com/pvictor/ee154cc600e82f3ed2ce0a333bc7d015
# https://data.lacity.org/Public-Safety/Crime-Data-from-2020-to-Present/2nrs-mtv8
# https://connect.thinkr.fr/hexmake/
# https://shiny.rstudio.com/reference/shiny/latest/selectInput.html
# https://www.geeksforgeeks.org/filter-multiple-values-on-a-string-column-in-r-using-dplyr/#:~:text=In%20this%2C%20first%2C%20pass%20your,you%20want%20in%20the%20result.
# https://stackoverflow.com/questions/50218614/shiny-selectinput-to-select-all-from-dropdown
# https://dreamrs.github.io/shinyWidgets/reference/pickerInput.html
# https://datasharkie.com/how-to-calculate-confidence-interval-in-r/
# https://stackoverflow.com/questions/20637248/shiny-4-small-textinput-boxes-side-by-side
# https://shiny.rstudio.com/reference/shiny/1.6.0/varSelectInput.html
